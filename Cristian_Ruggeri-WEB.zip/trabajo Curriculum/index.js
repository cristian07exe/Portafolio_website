let menuV = false;
//funcion que oculta o muestra el menu

function MostrarOcultarMenu(){
    if(menuV){
        document.getElementById("nav").classList="";
        menuV = false;
    }else{
        document.getElementById("nav").classList ="responsive";
        menuV =true
    }
}
function seleccionar(){
    document.getElementById("nav").classList = "";
    menuV = false;
}
//EFECTOS



        



